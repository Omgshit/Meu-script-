export interface PlayerSuggesting{
    user_id: string
    message_id: string
    escolha: string
}