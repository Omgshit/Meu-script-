type ChannelInfo = { channel_id: string, user_id: string, atended: boolean };

export interface TicketsData {
    ticket: ChannelInfo
}