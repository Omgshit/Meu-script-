export interface MemberData {
    channel_id: string
    userid: string
}