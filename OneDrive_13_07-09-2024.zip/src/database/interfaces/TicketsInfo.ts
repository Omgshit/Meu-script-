export interface TicketInfo{
    abertos: number,
    atendidos: number,
}