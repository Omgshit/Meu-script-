export type PlayerData = {
    user_id: string,
    escolha: string,
    last_date: string,
}