export type GuildMessages = {
    message: string
    message_on_send: string
}