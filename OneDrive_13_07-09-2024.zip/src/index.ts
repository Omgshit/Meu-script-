import { createClient } from "#base"; 

createClient().start();